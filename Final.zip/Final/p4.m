clear
close ALL HIDDEN
load('mimo_system')

w1 = 1; % rad/sec
w2 = 2; % rad/sec
t = linspace(0,99.9,1000)';
u1 = 1 + 2*sin(w1*t) + 3*sin(w2*t);
randn('seed',2);
u2 = randn(1000,1);
u = [u1 u2];
m=2;
r=1;

[Y,X] = dlsim(A,B,C,D,u);
[Y_bar, V_bar] = YV_Form_nonzero(u2',Y',6);
cap_y_hat = Y_bar'*pinv(V_bar);
RSMP = recover_SYSMP(cap_y_hat,100,m,r);

plot(reshape(MP(:,2,:),[],1))
hold on
plot(reshape(RSMP,[],1))
grid on
figure
plot(abs(reshape(MP(:,2,:)-RSMP,[],1)))