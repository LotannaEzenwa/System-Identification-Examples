clear
load('hubbledata.mat')
